console.log("To infinity and beyond.");

// write your JavaScript here
